/*  Copyright 2015 Larry Judd Oliver  (email : larry@tradesouthwest.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License, version 2, as 
    published by the Free Software Foundation.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
=== TSW Custom Profile ===
Contributors: larryjudd.us
Author URI: http://tradesouthwest.com/
Plugin URL: http://
Requires at Least: 1.0.1
Tested Up To: 1.0.1
Tags: template, wordpress, wordpress.org, custom-post
Stable tag: 201501010

== Description ==
This plugin is for use with any of the WordPress themes by TSW which need the Custom Profile Plugin to accommodate custom post types as an addon to the theme options.
